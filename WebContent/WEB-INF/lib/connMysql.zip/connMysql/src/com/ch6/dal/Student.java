package com.ch6.dal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.ch6.Conn;
import com.ch6.model.StudentInfo;
public class Student {

	Conn conn = new Conn();
	public List<StudentInfo> getList() throws SQLException{
			List<StudentInfo> list=new ArrayList<StudentInfo>();
			String sql="SELECT * FROM student ORDER BY number ASC";
			ResultSet rs=conn.executeQuery(sql);
			while (rs.next()){
				StudentInfo info=new StudentInfo();
				info.setId(rs.getString("Id"));
				info.setName(rs.getString("Name"));
				info.setNumber(rs.getString("Number"));
				info.setSex(rs.getString("Sex"));
				info.setAddress(rs.getString("Address"));
				info.setPhone(rs.getString("Phone"));
				info.setEmail(rs.getString("Email"));
				list.add(info);
			}
			conn.close();
			return list;	
	}
	
	public int insert(StudentInfo info)
	{
		String sql="insert into student(Number,Name,Sex,Address,Phone,Email)values ";
		sql = sql+"('"+info.getNumber()+"','"+info.getName()+"','"+info.getSex()+"','"+
		info.getAddress()+"','"+info.getPhone()+"','"+info.getEmail()+"')";
		int result = 0;
		System.out.println(sql);
		result = conn.executeUpdate(sql);
		conn.close();
		return result;
	}
	public int delete(String id)
	{
		String sql = "delete form student where id ='"+id+"'";
		int result = 0;
		System.out.println(sql);
		result = conn.executeUpdate(sql);
		conn.close();
		return result;
	}
	public int update(StudentInfo info){
		String	sql = "update  student set"+"number='"+info.getNumber()+"',name='"+info.getName()+"',sex='"+info.getSex()+"',address='"+
		info.getAddress()+"',phone='"+info.getPhone()+"',email='"+info.getEmail()+"'";
		int result = 0;
		System.out.println(sql);
		result = conn.executeUpdate(sql);
		conn.close();
		return result;
	}
	public StudentInfo getStudent(String id) throws SQLException{
		StudentInfo info=new StudentInfo();
		String sql="select * form student s where id='"+id+"'";
		ResultSet rs = conn.executeQuery(sql);
		if(rs.next())
		{
			info.setId(rs.getString("Id"));
			info.setName(rs.getString("Name"));
			info.setNumber(rs.getString("Number"));
			info.setSex(rs.getString("Sex"));
			info.setAddress(rs.getString("Address"));
			info.setPhone(rs.getString("Phone"));
			info.setEmail(rs.getString("Email"));
		}
		conn.close();
		return info;
	}
}

